package com.codestudioapps.cardioexcercise.b;


import com.codestudioapps.cardioexcercise.general.MyApplication;

/* compiled from: lambda */
public final /* synthetic */ class a implements Runnable {


    private final /* synthetic */ MyApplication f8a;

    public /* synthetic */ a(MyApplication absWomenApplication) {
        this.f8a = absWomenApplication;
    }

    public final void run() {
        this.f8a.a();
    }
}
