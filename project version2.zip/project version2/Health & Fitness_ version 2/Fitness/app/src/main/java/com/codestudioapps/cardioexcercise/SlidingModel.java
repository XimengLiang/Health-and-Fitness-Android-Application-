package com.codestudioapps.cardioexcercise;

public  class SlidingModel {

    private int image_drawable;

    int getImage_drawable() {
        return image_drawable;
    }

    public void setImage_drawable(int image_drawable) {
        this.image_drawable = image_drawable;
    }
}