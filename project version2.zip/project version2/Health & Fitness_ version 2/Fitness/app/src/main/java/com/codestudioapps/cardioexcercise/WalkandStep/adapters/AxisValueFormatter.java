package com.codestudioapps.cardioexcercise.WalkandStep.adapters;



import com.github.mikephil.charting.components.AxisBase;



@Deprecated
public interface AxisValueFormatter
{


    @Deprecated
    String getFormattedValue(float value, AxisBase axis);
}