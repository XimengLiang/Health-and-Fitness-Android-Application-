package com.codestudioapps.cardioexcercise.utils;

import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.preference.PreferenceManager;

import com.codestudioapps.cardioexcercise.WalkandStep.models.StepCount;
import com.codestudioapps.cardioexcercise.WalkandStep.persistence.StepCountPersistenceHelper;
import com.codestudioapps.cardioexcercise.WalkandStep.persistence.WalkingModePersistenceHelper;
import com.codestudioapps.cardioexcercise.general.MyApplication;

import java.text.SimpleDateFormat;
  import java.util.Calendar;
import java.util.Locale;

public class StepCounter implements SensorEventListener {
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private boolean isStepCounting;
    private int stepCount;

    public StepCounter(SensorManager sensorManager) {
        this.sensorManager = sensorManager;
        this.accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        this.isStepCounting = false;
        this.stepCount = 0;
    }

    public void start() {
        if (accelerometer != null) {
            sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            isStepCounting = true;
        }
    }

    public void stop() {
        sensorManager.unregisterListener(this);
        isStepCounting = false;
    }

    public int getStepCount() {
        return stepCount;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];

            // 根据加速度传感器的数据进行步数计算逻辑
            // 这里使用一个简单的算法来检测步伐
            float magnitude = (float) Math.sqrt(x * x + y * y + z * z);
            if (magnitude > 20) {
                stepCount++;
                final SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(MyApplication.getInstance());

                Calendar day =  Calendar.getInstance(Locale.ENGLISH);
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                String formattedDate = dateFormat.format(day.getTime());



                StepCount stepCountBean = StepCountPersistenceHelper.getLastStepCountEntryForDay(day, MyApplication.getInstance());
                if(stepCountBean == null){
                    stepCountBean = new StepCount();
                    stepCountBean.setStartTime(day.getTime().getTime());
                    stepCountBean.setEndTime(day.getTime().getTime());
                    stepCountBean.setStepCount(stepCount);
                    stepCountBean.setWalkingMode(WalkingModePersistenceHelper.getActiveMode(MyApplication.getInstance()));
                    StepCountPersistenceHelper.storeStepCount(stepCountBean, MyApplication.getInstance());
                    sharedPref.edit().putInt(formattedDate,stepCount);
                    sharedPref.edit().apply();
                    sharedPref.edit().commit();
                }else {
                    stepCountBean.setStepCount(stepCountBean.getStepCount() + stepCount);
                    StepCountPersistenceHelper.updateStepCount(stepCountBean, MyApplication.getInstance());
                    sharedPref.edit().putInt(formattedDate,stepCountBean.getStepCount() + stepCount);
                    sharedPref.edit().apply();
                    sharedPref.edit().commit();
                }
            }
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // 不需要处理
    }
}