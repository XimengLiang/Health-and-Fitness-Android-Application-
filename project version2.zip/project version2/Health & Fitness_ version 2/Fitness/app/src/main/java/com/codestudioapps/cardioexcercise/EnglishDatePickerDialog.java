package com.codestudioapps.cardioexcercise;

import android.app.DatePickerDialog;
import android.content.Context;
import android.widget.DatePicker;

import java.lang.reflect.Field;
import java.util.Locale;

public class EnglishDatePickerDialog extends DatePickerDialog {

    public EnglishDatePickerDialog(Context context, OnDateSetListener listener, int year, int month, int dayOfMonth) {
        super(context, listener, year, month, dayOfMonth);

        // 获取 DatePicker 对象
        DatePicker datePicker = getDatePicker();

        // 设置语言环境为英文
        setLocale(datePicker, Locale.ENGLISH);
    }

    private void setLocale(DatePicker datePicker, Locale locale) {
        // 通过反射获取 DatePicker 的 mDelegate 字段
        try {
            Field field = DatePicker.class.getDeclaredField("mDelegate");
            field.setAccessible(true);
            Object delegate = field.get(datePicker);

            // 通过反射获取 DatePickerDelegate 的 mLocale 字段
            Field localeField = delegate.getClass().getDeclaredField("mLocale");
            localeField.setAccessible(true);
            localeField.set(delegate, locale);

        } catch (NoSuchFieldException | IllegalAccessException | IllegalArgumentException e) {
            e.printStackTrace();
        }
    }
}